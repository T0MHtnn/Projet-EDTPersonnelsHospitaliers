//package Test;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
//
//import org.junit.jupiter.api.Test;
//import hopital.créneau;
//
//class TestCréneau {
//
//	private static String[] getCréneau(int id) {
//		try {
//			//1 - charger le driver mysql
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//2 - créer la connexion
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
//			//3 - créer un état de connexion
//			Statement st = con.createStatement();
//			//4 - créer une requete de sélection
//			ResultSet res = st.executeQuery("select * from créneau WHERE id = " + id + "");
//			//5 - parcours des données
//			String [] tab = new String [4];
//			int j = 2;
//			for(int i = 0; i < tab.length - 1; i++) {
//				tab[i] = res.getString(j);
//				j++;
//			}
//			
//			//6 - fermer la connexion
//			con.close();
//			return tab;
//			//7 - traitement des exceptions
//		}catch (Exception e) {
//			System.out.println(
//					"ERROR :" +e.getMessage());
//			
//		}
//		return null;
//	}
//	/**
//	 * la classe de test vérifie que le créneau est bien créé, 
//	 * pour cela on utilisera la méthode getCréneau() et on supposera
//	 * qu'on connais l'id du créneau, (dans cette exemple, 
//	 * il sera égal à 5
//	 * @return
//	 */
//	private boolean TestCréation() {
//		new créneau( "2023-11-03", "08:45:00",  "16:30:00",  6);
//		String tab [] = new String [4];
//		tab = getCréneau(5);
//		String tab2 [] = new String [4];
//		tab2[0] = "2023-11-03";
//		tab2[1] = "08:45:00";
//		tab2[2] = "16:30:00";
//		tab2[3] = "6";
//		
//		SuppCréneau(5);
//		return tab[0] == tab2[0] && tab[1] == tab2[1] && tab[2] == tab2[2] && tab[3] == tab2[3];
//	}
//	@Test
//	void LancerTestCréneau() {
//		assertTrue(TestCréation());
//	}
//
//}
