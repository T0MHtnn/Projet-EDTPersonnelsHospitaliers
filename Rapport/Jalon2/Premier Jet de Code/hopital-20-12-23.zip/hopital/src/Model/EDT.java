//package Model;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.ArrayList;
//
//import com.mysql.cj.protocol.Resultset;
//
///**
// * Cette classe permet la liaison entre un personnel, et les créneaux qui lui
// * sont associés, en outre en rajoutant l'id des créneaux à l'id du personnel
// */
//public class EDT {
//	
//	private int idPersonnel;
//	private String idCreneau;
//	private  ArrayList<Creneau> TabCréneau;
//	
//	public EDT(int idPersonnel, String idCreneau) {
//		this.idPersonnel = idPersonnel;
//		this.idCreneau = idCreneau;
//		creationEDT();
//	}
//	/**
//	 * Création d'un emploi du temps
//	 */
//	private void creationEDT() {
//		try {
//			//1 - charger le driver mysql
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//2 - créer la connexion
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
//			//3 - créer un état de connexion
//			Statement st = con.createStatement();
//			//4 - créer une requete de sélection
//			String query = "INSERT INTO edt (`idPersonnel`, `TabIDCreneau`) VALUES ('"+ idPersonnel +"', '"+ idCreneau +"')";
//			st.executeUpdate(query);
//			//6 - fermer la connexion
//			con.close();
//			//7 - traitement des exceptions
//		}catch(Exception e) {
//			System.out.println(
//					"ERROR :" +e.getMessage());
//		}
//	}
//	/**
//	 * Cette méthode permet de rajouter un créneau dans la liste de
//	 * créneau associé à un personnel en récupérant la liste au préalable
//	 * et l'a renvoie en ayant rajouté l'id du créneau passé en paramètre
//	 * @param idPersonnel
//	 * @param idCreneau
//	 */
//	public static void ajouterCreneauEDT(int idPersonnel, int idCreneau) {
//		try {
//			//1 - charger le driver mysql
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//2 - créer la connexion
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
//			//3 - créer un état de connexion
//			Statement st = con.createStatement();
//			//4 - créer une requete de sélection
//			String query = "SELECT TabIDCreneau FROM edt WHERE idPersonnel = " + idPersonnel;
//			ResultSet rs = st.executeQuery(query);
//			
//			if (rs.next()) {
//			    String z = rs.getString(1) + String.valueOf(idCreneau);
//			    String query2 = "UPDATE edt SET TabIDCreneau = '" + z + "' WHERE idPersonnel = " + idPersonnel;
//			    Statement st2 = con.createStatement();
//			    st2.executeUpdate(query2);
//
//			    // Fermer le deuxième statement
//			    st2.close();
//			}
//			
//			//6 - fermer la connexion
//			con.close();
//			//7 - traitement des exceptions
//		}catch(Exception e) {
//			System.out.println(
//					"ERROR :" +e.getMessage());
//		}
//	}
//	
//
//	/**
//	 * Cette méthode permet de récuperer les créneau associé à un personnel,
//	 * il prend en paramètre l'id du personnel en question et la méthode récupère
//	 * un string de créneau (il s'agit des id de chaque créneau), la découpe caractère 
//	 * par caractère, pour ensuite créer un tableau de créneau en fonction des id des créneaux,
//	 * qui ont été au préalable complété avec leur argument grâce à la méthode recupererCreneau()
//	 * de la classe créneau
//	 * @param idPersonnel
//	 * @return un tableau de créneau
//	 * @throws Exception
//	 * @author Dylan Cailleau
//	 */
//	@SuppressWarnings("finally")
//	public static ArrayList<Creneau> recupererCreneauEDT(int idPersonnel) throws Exception {
//		ArrayList<Creneau> TabCreneau = new ArrayList<>();
//		try { // connection à la base de donnée
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
//			Statement st = con.createStatement();
//			
//			String query = "SELECT TabIDCreneau FROM edt WHERE idPersonnel = " + idPersonnel;
//			ResultSet rs = st.executeQuery(query);
//			
//			if (rs.next()) {
//			    String z = rs.getString(1); // on attribut l'élément de la colonne TabIDCreneau au String z
//			    String [] z2 = z.split(""); // découpage de la chaine de caractère caractère par caractère
//			    
//			    for(int i = 0; i < z2.length; i++) { // on rajoute au tableau de créneau les attributs de chaque créneau correspond à leurs id, contenuent dans la chaine de caractère z2
//			    	TabCreneau.add(Creneau.recupererCreneau(Integer.parseInt(z2[i])));
//			    }
//			}
//			}catch(Exception e) {
//				System.out.print(
//						"ERROR : " + e.getMessage());
//			}
//			finally {
//				return TabCreneau;
//			}
//		
//	}
////	 public static ArrayList<créneau> getEmploiDuTemps(int idPersonnel, int semaineActuelle) {
////	        ArrayList<créneau> emploiDuTemps = new ArrayList<>();
////
////	        Connection connection = null;
////	        PreparedStatement statement = null;
////	        ResultSet resultSet = null;
////
////	        try {
////	            // Remplacez cet appel par votre méthode de connexion à la base de données
////				Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
////
////	            // Assurez-vous d'ajuster la requête SQL en fonction de votre structure de base de données
////	            String sql = "SELECT TabIDCreneau FROM edt WHERE idPersonnel = ?";
////	            statement = con.prepareStatement(sql);
////	            statement.setInt(1, idPersonnel);
////
////	            resultSet = statement.executeQuery();
////
////	            while (resultSet.next()) {
////	                // Obtenez la valeur de TabIDCreneau de la base de données
////	                String tabIDCreneau = resultSet.getString("TabIDCreneau");
////
////	                // Ajoutez une logique pour séparer les ID des créneaux et les ajouter à la liste
////	                String[] idCreneaux = tabIDCreneau.split(",");
////	                for (String idCreneau : idCreneaux) {
////	                    emploiDuTemps.add(créneau.recupererCreneau(Integer.parseInt(idCreneau.trim())));
////	                }
////	            }
////	        } catch (SQLException e) {
////	            e.printStackTrace();
////	        } finally {
////	            // Fermez les ressources ouvertes
////	            try {
////	                if (resultSet != null) resultSet.close();
////	                if (statement != null) statement.close();
////	                if (connection != null) connection.close();
////	            } catch (SQLException e) {
////	                e.printStackTrace();
////	            }
////	        }
////
////	        return emploiDuTemps;
////	    }
//	
//	public static void main(String[]args) {
////		EDT edt1 = new EDT(5, "1234");
////		ajouterCreneauEDT(2, 6);
//		try {
//			System.out.print(recupererCreneauEDT(5));
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
////		ArrayList<créneau> créneautest = new ArrayList<>();
////		créneautest.add(new créneau("2023-12-12","14:30:00", "17:50:00", 4));
////		créneautest.add(new créneau("2023-12-12","14:30:00", "17:50:00", 4));
////		créneautest.add(new créneau("2023-12-12","14:30:00", "17:50:00", 4));
////		créneautest.add(new créneau("2023-12-12","14:30:00", "17:50:00", 4));
////		System.out.print(toStringEDT(créneautest.get(0).idCreneau));
//	}
//}
