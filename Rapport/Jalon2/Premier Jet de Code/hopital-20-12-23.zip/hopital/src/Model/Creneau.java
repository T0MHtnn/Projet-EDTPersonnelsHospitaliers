package Model;

import java.sql.*;

public class Creneau {
	
	private int idCreneau;
	private Date date;
	private Time heure_de_début; 
	private Time heure_de_fin; 
	private int personnel_minimum;
	
	public Creneau(int id, Date date, Time heure_de_début, Time heure_de_fin, int personnel_minimum) {
		this.date = date;
		this.heure_de_début = heure_de_début;
		this.heure_de_fin = heure_de_fin;
		this.personnel_minimum = personnel_minimum;
	}

	public int getIdCreneau() {
		return idCreneau;
	}

	public void setIdCreneau(int idCreneau) {
		this.idCreneau = idCreneau;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Time getHeure_de_début() {
		return heure_de_début;
	}

	public void setHeure_de_début(Time heure_de_début) {
		this.heure_de_début = heure_de_début;
	}

	public Time getHeure_de_fin() {
		return heure_de_fin;
	}

	public void setHeure_de_fin(Time heure_de_fin) {
		this.heure_de_fin = heure_de_fin;
	}

	public int getPersonnel_minimum() {
		return personnel_minimum;
	}

	public void setPersonnel_minimum(int personnel_minimum) {
		this.personnel_minimum = personnel_minimum;
	}
	
}
