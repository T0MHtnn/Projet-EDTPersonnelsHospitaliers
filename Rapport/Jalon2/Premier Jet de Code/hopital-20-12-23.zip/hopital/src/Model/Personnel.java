package Model;

import java.sql.*;

public class Personnel {
	
	private int id;
	private String nom ;
	private String prenom;
	private Date date_de_naissance;
	private int fonction;
	private int specialite;
	private int temps_de_travail_mensuel; 
	
	public Personnel(int id, String nom ,String prénom,Date date_de_naissance,int fonction,int spécialité,int temps_de_travail_mensuel) {
		this.id = id;
		this.nom = nom;
		this.prenom = prénom;
		this.date_de_naissance = date_de_naissance;
		this.fonction = fonction;
		this.specialite = spécialité;
		this.temps_de_travail_mensuel = temps_de_travail_mensuel;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prénom) {
		this.prenom = prénom;
	}

	public Date getDate_de_naissance() {
		return date_de_naissance;
	}

	public void setDate_de_naissance(Date date_de_naissance) {
		this.date_de_naissance = date_de_naissance;
	}

	public int getFonction() {
		return fonction;
	}

	public void setFonction(int fonction) {
		this.fonction = fonction;
	}

	public int getSpecialite() {
		return specialite;
	}

	public void setSpecialite(int spécialité) {
		this.specialite = spécialité;
	}

	public int getTemps_de_travail_mensuel() {
		return temps_de_travail_mensuel;
	}

	public void setTemps_de_travail_mensuel(int temps_de_travail_mensuel) {
		this.temps_de_travail_mensuel = temps_de_travail_mensuel;
	}
	@Override
	public String toString() {
		return ( id + ", " + nom + ", " + prenom + ", " + date_de_naissance + ", " + fonction + ", " + specialite + ", " + temps_de_travail_mensuel );
	}

	public Date getDate() {
		return date_de_naissance;
	}
	
}
