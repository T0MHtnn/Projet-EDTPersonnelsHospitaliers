//package Model;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;
//
///**
// * @author Dylan Cailleau
// */
//
//public class fonction {
//	
//	private String nom;
//	
//	public fonction(String nom) {
//		this.nom = nom;
//		creationFonction();
//	}
//	
//	private void creationFonction() {
//		try {
//			//1 - charger le driver mysql
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//2 - créer la connexion
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
//			//3 - créer un état de connexion
//			Statement st = con.createStatement();
//			//4 - créer une requete de sélection
//			String query = "INSERT INTO fonction (`nom`) VALUES ('"+ nom +"')";
//			st.executeUpdate(query);
//			//6 - fermer la connexion
//			con.close();
//			//7 - traitement des exceptions
//		}catch (Exception e) {
//			System.out.println(
//					"ERROR :" +e.getMessage());
//			
//		}
//	}
//	public static void visualisationFonction(int id) {
//		try {
//			//1 - charger le driver mysql
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//2 - créer la connexion
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
//			//3 - créer un état de connexion
//			Statement st = con.createStatement();
//			//4 - créer une requete de sélection
//			ResultSet res = st.executeQuery("select * from fonction where id = " + id +"");
//			//5 - parcours des données
//			while(res.next()) {
//				System.out.println("La fonction correspondant à l'id : "+ id +" est : \nNom : " + res.getString(2) );
//			}
//			//6 - fermer la connexion
//			con.close();
//			//7 - traitement des exceptions
//		}catch (Exception e) {
//			System.out.println(
//					"ERROR :" +e.getMessage());
//			
//		}
//	}
//	public static void suppressionFonction(int id) {
//		try {
//			//1 - charger le driver mysql
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			//2 - créer la connexion
//			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hopital" , "root" , "root");
//			//3 - créer un état de connexion
//			Statement st = con.createStatement();
//			//4 - créer une requete de sélection
//			int res = st.executeUpdate("DELETE FROM `fonction` WHERE id = " + id +"");
//			//6 - fermer la connexion
//			con.close();
//			//7 - traitement des exceptions
//		}catch (Exception e) {
//			System.out.println(
//					"ERROR :" +e.getMessage());
//			
//		}
//	}
//	
//	public static void main(String[]args) {
//		fonction spe1 = new fonction("testfonction");
//		visualisationFonction(1);
//		suppressionFonction(3);
//	}
//}
