
package tableView;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import SQL.DbConnect;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import Model.Personnel;
import javafx.scene.control.TextFormatter;

/**
 * FXML Controller class
 *
 * @author hocin
 */
public class AddPersonnelController implements Initializable {

    @FXML
    private JFXTextField nomFld;
    @FXML
    private JFXTextField prenomFld;
    @FXML
    private JFXDatePicker dateFld;
    @FXML
    private JFXTextField fonctionFld;
    @FXML
    private JFXTextField specialiteFld;
    @FXML
    private JFXTextField tpstravailFld;
    
    private int fonction; 
    private int specialite; 
    private int tpstravail;

    String query = null;
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement preparedStatement;
    Personnel Personnel = null;
    private boolean update;
    int PersonnelId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void save(MouseEvent event) {
    	
        connection = DbConnect.getConnect();
        String nom = nomFld.getText();
        String prenom = prenomFld.getText();
        Date date = Date.valueOf(dateFld.getValue());
        // Les valeurs de fonction, specialite et tpstravail sont maintenant des entiers
        fonction = Integer.parseInt(fonctionFld.getText());
        specialite = Integer.parseInt(specialiteFld.getText());
        tpstravail = Integer.parseInt(tpstravailFld.getText());

        if (nom.isEmpty() 
        		|| prenom.isEmpty()
        		|| nom.isEmpty()
        		|| date == null 
        		|| fonction == 0
        		|| specialite == 0
        		|| tpstravail == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please Fill All DATA");
            alert.showAndWait();

        } else {
            getQuery();
            insert();
            clean();

        }

    }

    @FXML
    private void clean() {
        nomFld.setText(null);
        prenomFld.setText(null);
        dateFld.setValue(null);
        fonctionFld.setText(null);
        specialiteFld.setText(null);
        tpstravailFld.setText(null);
        
    }

    private void getQuery() {

        if (update == false) {
            
            query = "INSERT INTO `Personnel`(`id`, `nom`, `prenom`, `date_de_naissance`, `fonction`, `specialite`, `tps_travail_mensuel`) VALUES (NULL,?,?,?,?,?,?)";

        }else{
            query = "UPDATE `Personnel` SET "
                    + "`nom`=?,"
                    + "`prenom`=?,"
                    + "`date_de_naissance`=?,"
                    + "`fonction`=?,"
                    + "`specialite`=?,"
                    + "`tps_travail_mensuel`= ? WHERE id = '"+PersonnelId+"'";
        }

    }

    private void insert() {

        try {

        	preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nomFld.getText());
            preparedStatement.setString(2, prenomFld.getText());
            
         // Convertir LocalDate en java.sql.Date
            LocalDate localDate = dateFld.getValue();
            java.sql.Date date = java.sql.Date.valueOf(localDate);
            
            preparedStatement.setDate(3, date);
            preparedStatement.setInt(4, fonction);
            preparedStatement.setInt(5, specialite);
            preparedStatement.setInt(6, tpstravail);
            preparedStatement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(AddPersonnelController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void setTextField(int id, String nom, String prenom, Date date, int fonction, int specialite, int tpstravail) {

        PersonnelId = id;
        nomFld.setText(nom);
        prenomFld.setText(prenom);
        
     // Convertir java.sql.Date en LocalDate
        LocalDate localDate = date.toLocalDate();
        
        dateFld.setValue(localDate);
        fonctionFld.setText(String.valueOf(fonction));
        specialiteFld.setText(String.valueOf(specialite));
        tpstravailFld.setText(String.valueOf(tpstravail));

    }

    void setUpdate(boolean b) {
        this.update = b;

    }

	

}
