package Operations;

import java.io.IOException;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
/**
 * Stage Styles principaux :
 * DECORED
 * UNDECORATED
 * TRANSPARENT
 * 
 * @author Dylan Cailleau
 *
 */

/*
 * new Scene(<root>, <color>)
 * new Scene(<root>, <w>, <h>, <color>)
 */

/**
 * @author Dylan Cailleau
 */

public class App extends Application{

	@Override
	public void start(Stage primaryStage) {
			Parent root;
			try {
				System.out.println("test1");
				root = FXMLLoader.load(getClass().getResource("/tableView/Main.fxml")); // le problème à lieu lors du chargement du fxml
				Scene scene = new Scene(root);
				primaryStage.setScene(scene);
				primaryStage.show();
				primaryStage.centerOnScreen();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
//			FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("Main.fxml"));
//			Scene scene = new Scene(fxmlLoader.load(), 600, 400);
//			primaryStage.setTitle("projet");
//			primaryStage.setScene(scene);
//			primaryStage.show();	
	}
	/**
	 * la méthode main n'est pas obligatoire pour lancer la fenêtre, 
	 * toutefois elle reste importante pour afficher les erreurs en console
	 * @param args
	 */
	public static void main(String[]args) {
		launch(args); 
	}

}
